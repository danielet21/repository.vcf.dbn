import xbmc
import xbmcgui
import xbmcaddon
import urllib.request
import json
from datetime import datetime

API_KEY = '0c4b6df736bf4e77902183122fd996c3'
API_URL = 'https://api.football-data.org/v4/competitions/PD/matches?status=SCHEDULED'

DIAS = {
    'Monday': 'Lunes', 'Tuesday': 'Martes', 'Wednesday': 'Miércoles',
    'Thursday': 'Jueves', 'Friday': 'Viernes', 'Saturday': 'Sábado', 'Sunday': 'Domingo'
}
MESES = {
    1: 'Ene', 2: 'Feb', 3: 'Mar', 4: 'Abr', 5: 'May', 6: 'Jun',
    7: 'Jul', 8: 'Ago', 9: 'Sep', 10: 'Oct', 11: 'Nov', 12: 'Dic'
}

def get_next_match():
    try:
        req = urllib.request.Request(API_URL, headers={'X-Auth-Token': API_KEY})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))

        matches = data.get('matches', [])
        vcf_matches = [m for m in matches if
                       m.get('homeTeam', {}).get('id') == 95 or
                       m.get('awayTeam', {}).get('id') == 95]

        if not vcf_matches:
            return None

        match = vcf_matches[0]
        home_id = match['homeTeam'].get('id')
        home_name = match['homeTeam'].get('shortName') or match['homeTeam']['name']
        away_name = match['awayTeam'].get('shortName') or match['awayTeam']['name']
        home_crest = match['homeTeam'].get('crest', '')
        away_crest = match['awayTeam'].get('crest', '')
        competition = match['competition']['name']
        utc_date = match['utcDate']

        dt = datetime.strptime(utc_date, '%Y-%m-%dT%H:%M:%SZ')
        dia_semana = DIAS.get(dt.strftime('%A'), dt.strftime('%A'))
        fecha = '{} {} {}'.format(dia_semana, dt.day, MESES[dt.month])
        hora = '{}:{:02d}h'.format(dt.hour + 1, dt.minute)

        if home_id == 95:
            lugar = 'Mestalla'
        else:
            lugar = 'Fuera'

        return {
            'home': home_name, 'away': away_name,
            'home_crest': home_crest, 'away_crest': away_crest,
            'fecha': fecha, 'hora': hora,
            'competicion': competition, 'lugar': lugar,
            'canal': 'No disponible',
        }

    except Exception as e:
        xbmc.log('VCF NextMatch ERROR: {}'.format(str(e)), xbmc.LOGERROR)
        return None


def set_window_properties(match):
    win = xbmcgui.Window(10000)
    if match:
        win.setProperty('VCF.NextMatch.Home', match['home'])
        win.setProperty('VCF.NextMatch.Away', match['away'])
        win.setProperty('VCF.NextMatch.HomeCrest', match['home_crest'])
        win.setProperty('VCF.NextMatch.AwayCrest', match['away_crest'])
        win.setProperty('VCF.NextMatch.Fecha', match['fecha'])
        win.setProperty('VCF.NextMatch.Hora', match['hora'])
        win.setProperty('VCF.NextMatch.Competicion', match['competicion'])
        win.setProperty('VCF.NextMatch.Lugar', match['lugar'])
        win.setProperty('VCF.NextMatch.Canal', match['canal'])
        win.setProperty('VCF.NextMatch.Available', 'true')
    else:
        win.setProperty('VCF.NextMatch.Available', 'false')


if __name__ == '__main__':
    match = get_next_match()
    set_window_properties(match)
