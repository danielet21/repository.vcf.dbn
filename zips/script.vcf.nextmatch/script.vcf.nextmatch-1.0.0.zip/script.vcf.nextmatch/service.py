import xbmc
import xbmcgui
import xbmcvfs
import urllib.request
import json
import threading
from datetime import datetime

API_KEY = '0c4b6df736bf4e77902183122fd996c3'
API_URL = 'https://api.football-data.org/v4/competitions/PD/matches?status=SCHEDULED'
AUDIO1 = 'special://home/addons/skin.vcf.dbn/media/audio1.mp3'
AUDIO2 = 'special://home/addons/skin.vcf.dbn/media/audio2.mp3'

DIAS = {'Monday':'Lunes','Tuesday':'Martes','Wednesday':'Miércoles',
        'Thursday':'Jueves','Friday':'Viernes','Saturday':'Sábado','Sunday':'Domingo'}
MESES = {1:'Ene',2:'Feb',3:'Mar',4:'Abr',5:'May',6:'Jun',
         7:'Jul',8:'Ago',9:'Sep',10:'Oct',11:'Nov',12:'Dic'}

def get_next_match():
    try:
        req = urllib.request.Request(API_URL, headers={'X-Auth-Token': API_KEY})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode('utf-8'))
        vcf = [m for m in data.get('matches',[])
               if m.get('homeTeam',{}).get('id')==95 or m.get('awayTeam',{}).get('id')==95]
        if not vcf:
            return None
        m = vcf[0]
        home_id = m['homeTeam'].get('id')
        dt = datetime.strptime(m['utcDate'], '%Y-%m-%dT%H:%M:%SZ')
        return {
            'home': m['homeTeam'].get('shortName') or m['homeTeam']['name'],
            'away': m['awayTeam'].get('shortName') or m['awayTeam']['name'],
            'home_crest': m['homeTeam'].get('crest',''),
            'away_crest': m['awayTeam'].get('crest',''),
            'fecha': '{} {} {}'.format(DIAS.get(dt.strftime('%A'), dt.strftime('%A')), dt.day, MESES[dt.month]),
            'hora': '{}:{:02d}h'.format(dt.hour+1, dt.minute),
            'lugar': 'Mestalla' if home_id==95 else 'Fuera',
            'canal': 'No disponible',
        }
    except Exception as e:
        xbmc.log('VCF ERROR: {}'.format(e), xbmc.LOGERROR)
        return None

def set_properties(match):
    w = xbmcgui.Window(10000)
    if match:
        w.setProperty('VCF.NextMatch.Home', match['home'])
        w.setProperty('VCF.NextMatch.Away', match['away'])
        w.setProperty('VCF.NextMatch.HomeCrest', match['home_crest'])
        w.setProperty('VCF.NextMatch.AwayCrest', match['away_crest'])
        w.setProperty('VCF.NextMatch.Fecha', match['fecha'])
        w.setProperty('VCF.NextMatch.Hora', match['hora'])
        w.setProperty('VCF.NextMatch.Lugar', match['lugar'])
        w.setProperty('VCF.NextMatch.Canal', match['canal'])
        w.setProperty('VCF.NextMatch.Available', 'true')
    else:
        w.setProperty('VCF.NextMatch.Available', 'false')


class AudioWatchdog(threading.Thread):
    """Hilo independiente que mantiene audio2 sonando siempre"""
    def __init__(self):
        super().__init__(daemon=True)
        self.active = False
        self.stop_event = threading.Event()
        self.player = xbmc.Player()
        self._path2 = xbmcvfs.translatePath(AUDIO2)

    def start_loop(self):
        self.active = True

    def shutdown(self):
        self.stop_event.set()

    def _is_playing_audio(self):
        return self.player.isPlaying() and not self.player.isPlayingVideo()

    def _play_audio2(self):
        pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        pl.clear()
        pl.add(self._path2)
        self.player.play(pl)
        xbmc.sleep(800)
        xbmc.executebuiltin('PlayerControl(RepeatOne)')
        xbmc.log('VCF: watchdog inició audio2', xbmc.LOGINFO)

    def run(self):
        while not self.stop_event.is_set():
            if self.active:
                if self.player.isPlayingVideo():
                    xbmc.sleep(2000)
                    continue
                if not self._is_playing_audio():
                    xbmc.log('VCF: watchdog detectó silencio, reiniciando audio2', xbmc.LOGINFO)
                    self._play_audio2()
            xbmc.sleep(3000)


class VCFService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.player = xbmc.Player()
        self.watchdog = AudioWatchdog()
        self.watchdog.start()

    def _play_audio1(self):
        path = xbmcvfs.translatePath(AUDIO1)
        if not xbmcvfs.exists(path):
            xbmc.log('VCF: audio1 no encontrado', xbmc.LOGWARNING)
            return False
        xbmc.executebuiltin('PlayerControl(RepeatOff)')
        pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        pl.clear()
        pl.add(path)
        self.player.play(pl)
        xbmc.log('VCF: audio1 iniciado', xbmc.LOGINFO)
        return True

    def run(self):
        xbmc.sleep(2000)
        set_properties(get_next_match())

        # FASE 1 — audio1 una vez
        if self._play_audio1():
            xbmc.sleep(1500)
            while not self.abortRequested():
                if not self.player.isPlaying():
                    xbmc.log('VCF: audio1 terminado', xbmc.LOGINFO)
                    break
                xbmc.sleep(500)

        # FASE 2 — pausa 3 segundos
        xbmc.log('VCF: pausa 3s antes de audio2', xbmc.LOGINFO)
        for _ in range(3):
            if self.abortRequested():
                break
            xbmc.sleep(1000)

        # FASE 3 — watchdog activo, audio2 suena para siempre
        xbmc.log('VCF: activando watchdog audio2', xbmc.LOGINFO)
        self.watchdog.start_loop()

        # Actualizar partido cada hora
        counter = 0
        while not self.abortRequested():
            if self.waitForAbort(10):
                break
            counter += 1
            if counter >= 360:
                counter = 0
                set_properties(get_next_match())

        self.watchdog.shutdown()


if __name__ == '__main__':
    VCFService().run()
